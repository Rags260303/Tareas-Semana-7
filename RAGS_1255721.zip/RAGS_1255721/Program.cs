﻿using System;

namespace RAGS_1255721
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese su nombre: ");
            String nombre = Console.ReadLine();

            Console.WriteLine("Hola mundo");
            Console.WriteLine("soy " + nombre);

            Console.Write("Hola mundo ");
            Console.Write("soy " + nombre);
            
            Console.ReadKey();
        }
    }
}
